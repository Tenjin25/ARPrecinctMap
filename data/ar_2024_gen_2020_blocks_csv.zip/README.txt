Arkansas 2024 General Election Results Disaggregated to the 2020 Block

## RDH Date Retrieval
10/14/2026

## Sources
Precinct shapefile with election results retrieved from the (Redistricting Data Hub)[https://redistrictingdatahub.org/dataset/arkansas-2024-general-election-precinct-level-results-and-boundaries/]
Block shapefiles and data are retrieved from the (Redistricting Data Hub)[https://redistrictingdatahub.org/dataset/arkansas-block-pl-94171-2020-by-table/] and originally from the Census Bureau's Public Law 94-171 dataset and TIGER shapefiles.

## Notes on Field Names:
Columns reporting votes generally follow the pattern:
One example is:
G16PREDCLI
The first character is G for a general election, P for a primary, S for a special, and R for a runoff.
Characters 2 and 3 are the year of the election.
Characters 4-6 represent the office type (see list below).
Character 7 represents the party of the candidate.
Characters 8-10 are the first three letters of the candidate's last name.

Office Codes Used:
AMD# - Constitutional Amendment
PRE - US President
TRE - State Treasurer
CON## - US Congress
SL### - State House
SU## - State Senate


Party Codes Used:
A - American Solidarity
D - Democrat
G - Green
I - Independent
L - Libertarian
N - Non-partisan
O - Other / Write-In
P - Prohibition (NAP)
R - Republican

## Fields:
Field Name   Description
GEOID20      Unique Block Identifier
STATEFP      State FIPS Code
COUNTYFP     County FIPS Code
PRECINCTID   Precinct Identifier
VAP_MOD      Modified Voting Age Population
G24AMD1NO    Issue No. 1: A Constitutional Amendment to Provide that Lottery Proceeds May Be Used to Fund or Provide Scholarships and Grants to Arkansas Citizens Enrolled in Vocational-Technical Schools and Technical Institutes-:-AGAINST-:-NON
G24AMD1YES   Issue No. 1: A Constitutional Amendment to Provide that Lottery Proceeds May Be Used to Fund or Provide Scholarships and Grants to Arkansas Citizens Enrolled in Vocational-Technical Schools and Technical Institutes-:-FOR-:-NON
G24AMD2NO    Issue No. 2: An amendment requiring local voter approval in a countywide special election for certain new casino licenses and repealing authority to issue a casino license in Pope County, Arkansas-:-AGAINST-:-NON
G24AMD2YES   Issue No. 2: An amendment requiring local voter approval in a countywide special election for certain new casino licenses and repealing authority to issue a casino license in Pope County, Arkansas-:-FOR-:-NON
G24PREASON   U.S. President-:-Peter Sonski/Lauren Onak-:-ASP
G24PREDHAR   U.S. President-:-Kamala D. Harris/Tim Walz-:-DEM
G24PREGSTE   U.S. President-:-Jill Stein/Rudolph Ware-:-GRN
G24PREIKEN   U.S. President-:-Robert F. Kennedy, Jr./Nicole Shanahan-:-IND
G24PRELOLI   U.S. President-:-Chase Oliver/Mike ter Maat-:-LIB
G24PRENWOO   U.S. President-:-Michael Wood/John G. Pietrowski-:-NAP
G24PRERTRU   U.S. President-:-Donald J. Trump/JD Vance-:-REP
G24TREDPAG   State Treasurer-:-John Pagan-:-DEM
G24TRELPAK   State Treasurer-:-Michael Pakko-:-LIB
G24TRERTHU   State Treasurer-:-Secretary of State John Thurston-:-REP
GCON01DGOV   U.S. Congress District 01-:-Rodney Govens-:-DEM
GCON01LPAR   U.S. Congress District 01-:-Steve G. Parsons-:-LIB
GCON01RCRA   U.S. Congress District 01-:-Congressman Rick Crawford-:-REP
GCON02DJON   U.S. Congress District 02-:-Marcus A. Jones-:-DEM
GCON02RHIL   U.S. Congress District 02-:-Congressman French Hill-:-REP
GCON03DDRA   U.S. Congress District 03-:-Caitlin Draper-:-DEM
GCON03LWIL   U.S. Congress District 03-:-Bobby Wilson-:-LIB
GCON03RWOM   U.S. Congress District 03-:-Congressman Steve Womack-:-REP
GCON04DHOW   U.S. Congress District 04-:-Risie Howard-:-DEM
GCON04RWES   U.S. Congress District 04-:-Congressman Bruce Westerman-:-REP
GSC1NBAK     State Supreme Court Chief Justice Position 1-:-Arkansas Supreme Court Justice Karen Baker-:-NON
GSC1NWOO     State Supreme Court Chief Justice Position 1-:-Supreme Court Justice Rhonda Wood-:-NON
GSL001RWOO   State Representative District 01-:-State Representative Jeremy Wooldridge-:-REP
GSL002RSTE   State Representative District 02-:-State Representative Trey Steimel-:-REP
GSL003RPAI   State Representative District 03-:-State Representative Stetson Painter-:-REP
GSL004RNAZ   State Representative District 04-:-Jason Nazarenko-:-REP
GSL005RMCN   State Representative District 05-:-State Representative Ron McNair-:-REP
GSL006DDEL   State Representative District 06-:-Rick Delaney-:-DEM
GSL006LLOG   State Representative District 06-:-Dakota Logan-:-LIB
GSL006RBRE   State Representative District 06-:-State Representative Harlan Breaux-:-REP
GSL007DMCP   State Representative District 07-:-David McPherson-:-DEM
GSL007RMCK   State Representative District 07-:-State Representative Brit McKenzie-:-REP
GSL008LKAL   State Representative District 08-:-Michael J. Kalagias-:-LIB
GSL008RMCC   State Representative District 08-:-Representative Austin McCollum-:-REP
GSL009DWOR   State Representative District 09-:-Diana Gonzales Worthen-:-DEM
GSL009RHOD   State Representative District 09-:-State Representative DeAnna Hodges-:-REP
GSL010DSCH   State Representative District 10-:-Kate Schaffer-:-DEM
GSL010RMCA   State Representative District 10-:-State Representative Mindy McAlindon-:-REP
GSL011DHER   State Representative District 11-:-Rey Hernandez-:-DEM
GSL011RBUR   State Representative District 11-:-State Representative Rebecca Burkes-:-REP
GSL012DBAR   State Representative District 12-:-David L. Barber-:-DEM
GSL012RDUK   State Representative District 12-:-State Representative Hope Hendren Duke-:-REP
GSL013DSHE   State Representative District 13-:-Ashley Sheys-:-DEM
GSL013RRIC   State Representative District 13-:-State Representative R. Scott Richardson-:-REP
GSL014DMAL   State Representative District 14-:-Jacob Malloy-:-DEM
GSL014RBUR   State Representative District 14-:-Nick Burkes-:-REP
GSL015DFUN   State Representative District 15-:-Stephanie Funk-:-DEM
GSL015RCAR   State Representative District 15-:-State Representative John P. Carr-:-REP
GSL016RUND   State Representative District 16-:-Representative Kendon Underwood-:-REP
GSL017RTOR   State Representative District 17-:-Randy Torres-:-REP
GSL018DMEE   State Representative District 18-:-Justin Meeks-:-DEM
GSL018RLUN   State Representative District 18-:-State Representative Robin Lundstrum-:-REP
GSL019DCOO   State Representative District 19-:-Billy Cook-:-DEM
GSL019RUNG   State Representative District 19-:-Representative Steve Unger-:-REP
GSL020DGAR   State Representative District 20-:-Representative Denise Garner-:-DEM
GSL021DCLO   State Representative District 21-:-Representative Nicole Clowney-:-DEM
GSL022DWHI   State Representative District 22-:-State Representative David Whitaker-:-DEM
GSL023RMOO   State Representative District 23-:-State Representative Kendra Moore-:-REP
GSL024DINT   State Representative District 24-:-Ryan Intchauspe-:-DEM
GSL024RHAL   State Representative District 24-:-Brad Hall-:-REP
GSL025DOXF   State Representative District 25-:-Caitlin Tannehill Oxford-:-DEM
GSL025RPUR   State Representative District 25-:-State Representative Chad Puryear-:-REP
GSL026REAT   State Representative District 26-:-James Eaton-:-REP
GSL027RWAL   State Representative District 27-:-State Representative Steven Walker-:-REP
GSL028RSCH   State Representative District 28-:-State Representative Bart Schulz-:-REP
GSL029RMCC   State Representative District 29-:-State Representative Rick McClure-:-REP
GSL030DHOL   State Representative District 30-:-Hamilton Holmes-:-DEM
GSL030RCAV   State Representative District 30-:-State Representative Fran Cavenaugh-:-REP
GSL031RGAZ   State Representative District 31-:-State Representative Jimmy Gazaway-:-REP
GSL032DMCA   State Representative District 32-:-David McAvoy-:-DEM
GSL032LMCG   State Representative District 32-:-Eric I.B. McGee-:-LIB
GSL032RLAD   State Representative District 32-:-State Representative Jack Ladyman-:-REP
GSL033RMIL   State Representative District 33-:-State Representative Jon Milligan-:-REP
GSL034DHAM   State Representative District 34-:-Desmond Hammett-:-DEM
GSL034RCAR   State Representative District 34-:-State Representative Joey Carr-:-REP
GSL035DMCG   State Representative District 35-:-Jessie McGruder-:-DEM
GSL035RTHO   State Representative District 35-:-Justice Robert Thorne, Jr.-:-REP
GSL036DPAR   State Representative District 36-:-Daniel Parker-:-DEM
GSL036RRYE   State Representative District 36-:-Representative Johnny Rye-:-REP
GSL037DHEA   State Representative District 37-:-Lisa Head-:-DEM
GSL037RHOL   State Representative District 37-:-Representative Steve Hollowell-:-REP
GSL038RTOS   State Representative District 38-:-State Representative Dwight Tosh-:-REP
GSL039RLON   State Representative District 39-:-State Representative Wayne Long-:-REP
GSL040RPEA   State Representative District 40-:-State Representative Shad Pearce-:-REP
GSL041DNOW   State Representative District 41-:-Tom Nowlin-:-DEM
GSL041RBRO   State Representative District 41-:-Alyssa Brown-:-REP
GSL042DFAU   State Representative District 42-:-Lauren Faulk-:-DEM
GSL042RMEE   State Representative District 42-:-Representative Stephen Meeks-:-REP
GSL043RBEC   State Representative District 43-:-Representative Rick Beck-:-REP
GSL044RBER   State Representative District 44-:-State Representative Stan Berry-:-REP
GSL045DFRE   State Representative District 45-:-Whitney Sheree Freeman-:-DEM
GSL045RPIL   State Representative District 45-:-State Representative Aaron M. Pilkington-:-REP
GSL046REUB   State Representative District 46-:-State Representative Jon S. Eubanks-:-REP
GSL047RJOH   State Representative District 47-:-State Representative Lee Johnson-:-REP
GSL048RROS   State Representative District 48-:-State Representative Ryan A. Rose-:-REP
GSL049DRIC   State Representative District 49-:-Representative Jay Richardson-:-DEM
GSL050DMCC   State Representative District 50-:-Robin W. McCray-:-DEM
GSL050RGRA   State Representative District 50-:-State Representative Zack Gramlich-:-REP
GSL051DUDO   State Representative District 51-:-Jane-Ellen Udouj-Kutchka-:-DEM
GSL051RCRA   State Representative District 51-:-State Representative Cindy Crawford-:-REP
GSL052RRIC   State Representative District 52-:-State Representative Marcus E. Richmond-:-REP
GSL053DGAT   State Representative District 53-:-Amie Gates-:-DEM
GSL053RDUF   State Representative District 53-:-State Representative Matt Duffield-:-REP
GSL054DCOR   State Representative District 54-:-Doug Corbitt-:-DEM
GSL054RBEN   State Representative District 54-:-State Representative Mary Bentley-:-REP
GSL055DNAT   State Representative District 55-:-Cynthia Nations-:-DEM
GSL055RBRO   State Representative District 55-:-State Representative Matt Brown-:-REP
GSL056DMAG   State Representative District 56-:-State Representative Steve Magie-:-DEM
GSL056RSLA   State Representative District 56-:-Kim Slaughter-:-REP
GSL057DBOL   State Representative District 57-:-Ciara' Bolte-:-DEM
GSL057RCOO   State Representative District 57-:-Representative Cameron Cooper-:-REP
GSL058DMCG   State Representative District 58-:-Trevor McGarrah-:-DEM
GSL058REAV   State Representative District 58-:-State Representative Les Eaves-:-REP
GSL059RWOO   State Representative District 59-:-State Rep. Jim Wooten-:-REP
GSL060RLYN   State Representative District 60-:-State Representative Roger D. Lynch-:-REP
GSL061LSHE   State Representative District 61-:-Garrett Sheeks-:-LIB
GSL061RMOO   State Representative District 61-:-Representative Jeremiah Moore-:-REP
GSL062DMIL   State Representative District 62-:-Dexter R. Miller-:-DEM
GSL062RMCE   State Representative District 62-:-State Representative Mark D. McElroy-:-REP
GSL063DBAR   State Representative District 63-:-Mayor Lincoln Barnett-:-DEM
GSL063RBEL   State Representative District 63-:-Tammi Northcutt Bell-:-REP
GSL064DFER   State Representative District 64-:-State Representative Ken Ferguson-:-DEM
GSL065DBAR   State Representative District 65-:-Glenn Barnes-:-DEM
GSL066DPER   State Representative District 66-:-State Representative Mark W. Perry-:-DEM
GSL066RBAL   State Representative District 66-:-Wayne M. Ball-:-REP
GSL067DEBE   State Representative District 67-:-Andrew Cade Eberly-:-DEM
GSL067RBRO   State Representative District 67-:-Representative Karilyn Brown-:-REP
GSL068DBAR   State Representative District 68-:-Tom Bartole-:-DEM
GSL068REVA   State Representative District 68-:-State Representative Brian S. Evans-:-REP
GSL069DABD   State Representative District 69-:-Kwami Abdul-Bey-:-DEM
GSL069RRAY   State Representative District 69-:-State Representative David Ray-:-REP
GSL070DHOL   State Representative District 70-:-Alex Holladay-:-DEM
GSL070RWIN   State Representative District 70-:-State Representative Carlton Wing-:-REP
GSL071DGRE   State Representative District 71-:-Cassandra D. Green-:-DEM
GSL071RACH   State Representative District 71-:-State Representative Brandon Achor-:-REP
GSL072DSTE   State Representative District 72-:-Tracy Steele-:-DEM
GSL073DCOL   State Representative District 73-:-Representative Andrew Collins-:-DEM
GSL074DMCC   State Representative District 74-:-Representative Tippi McCullough-:-DEM
GSL075DHUD   State Representative District 75-:-Representative Ashley Hudson-:-DEM
GSL075LWHI   State Representative District 75-:-Michael White-:-LIB
GSL076DSPR   State Representative District 76-:-Representative Joy C. Springer-:-DEM
GSL077DALL   State Representative District 77-:-State Representative Fred Allen-:-DEM
GSL078DBAR   State Representative District 78-:-James Henry Bartolomei-:-DEM
GSL078RBRO   State Representative District 78-:-Representative Keith Brooks-:-REP
GSL079DSHE   State Representative District 79-:-State Representative Tara Shephard-:-DEM
GSL080DENN   State Representative District 80-:-State Representative Denise Ennett-:-DEM
GSL081DTHO   State Representative District 81-:-City Council Member Gina Thomas-Littlejohn-:-DEM
GSL081RHAW   State Representative District 81-:-State Representative RJ Hawk-:-REP
GSL082DBRA   State Representative District 82-:-Samuel Brazell, Jr.-:-DEM
GSL082RFUR   State Representative District 82-:-State Representative Tony Furman-:-REP
GSL083DDAN   State Representative District 83-:-Teresa Dannaway-:-DEM
GSL083RCHI   State Representative District 83-:-Paul Childress-:-REP
GSL084DSUM   State Representative District 84-:-Jill Summerford-:-D
GSL084RWAR   State Representative District 84-:-State Representative Les Warren-:-R
GSL085DMCK   State Representative District 85-:-Cortney Warwick McKee-:-D
GSL085RMCG   State Representative District 85-:-State Representative Richard McGrew-:-R
GSL086DBRA   State Representative District 86-:-Bill Bradshaw-:-DEM
GSL086RMAD   State Representative District 86-:-State Representative John Maddox-:-REP
GSL087LROS   State Representative District 87-:-Marc Rosson-:-LIB
GSL087RVAU   State Representative District 87-:-State Representative DeAnn Vaught-:-REP
GSL088LGOO   State Representative District 88-:-Tammy L. Goodwin-:-LIB
GSL088RHEN   State Representative District 88-:-Dolly Henley-:-REP
GSL089RGON   State Representative District 89-:-State Representative Justin Gonzales-:-REP
GSL090RWOM   State Representative District 90-:-Representative Richard Womack-:-REP
GSL091RCOZ   State Representative District 91-:-State Representative Bruce Cozart-:-R
GSL092DMUR   State Representative District 92-:-David Murray-:-DEM
GSL092RMAY   State Representative District 92-:-State Representative Julie Mayberry-:-REP
GSL093RHOL   State Representative District 93-:-State Representative Mike Holcomb-:-REP
GSL094DTAY   State Representative District 94-:-Annette Taylor-:-DEM
GSL094RWAR   State Representative District 94-:-State Representative Jeff Wardlaw-:-REP
GSL095RBEA   State Representative District 95-:-Representative Howard M. Beaty, Jr.-:-REP
GSL096DROA   State Representative District 96-:-Robin G. Roark-:-DEM
GSL096RBAR   State Representative District 96-:-State Representative Sonia Eubanks Barker-:-REP
GSL097DCAR   State Representative District 97-:-O'Dell Carr-:-DEM
GSL097RSHE   State Representative District 97-:-State Representative Matthew J. Shepherd-:-REP
GSL098RAND   State Representative District 98-:-State Representative Wade Andrews-:-REP
GSL099RJEA   State Representative District 99-:-State Representative Lane Jean-:-REP
GSL100RDAL   State Representative District 100-:-REP Carol Dalby-:-REP
GSU01LWIL    State Senate District 01-:-Asher Williams-:-LIB
GSU01RGIL    State Senate District 01-:-Senator Ben Gilmore-:-REP
GSU03RCRO    State Senate District 03-:-Senator Steve Crowell-:-REP
GSU04LGOO    State Senate District 04-:-Lonny Mack Goodwin-:-LIB
GSU04RHIC    State Senate District 04-:-Senator Jimmy Hickey, Jr.-:-REP
GSU05RRIC    State Senate District 05-:-Senator Terry Rice-:-REP
GSU06RMCK    State Senate District 06-:-Senator Matt McKee-:-R
GSU08DFLO    State Senate District 08-:-Senator Stephanie Flowers-:-DEM
GSU12DSCO    State Senate District 12-:-Representative Jamie Scott-:-DEM
GSU17DSKI    State Senate District 17-:-Maureen Skinner-:-DEM
GSU17RJOH    State Senate District 17-:-Senator Mark Johnson-:-REP
GSU18RDIS    State Senate District 18-:-Senator Jonathan Dismang-:-REP
GSU19RWAL    State Senate District 19-:-Senator Dave Wallace-:-REP
GSU20DASK    State Senate District 20-:-Erika Askeland-:-DEM
GSU20RSUL    State Senate District 20-:-State Senator Dan Sullivan-:-REP
GSU22DMAI    State Senate District 22-:-Sandy Maier-:-DEM
GSU22RPAY    State Senate District 22-:-Senator John Payton-:-REP
GSU23RFLI    State Senate District 23-:-Senator Scott Flippo-:-REP
GSU25DJUS    State Senate District 25-:-Michelle Justice-:-DEM
GSU25RDAV    State Senate District 25-:-Senator Breanne Davis-:-REP
GSU26RSTU    State Senate District 26-:-State Senator Gary Stubblefield-:-REP
GSU29RPET    State Senate District 29-:-State Senator Jim Petty-:-REP
GSU33RHES    State Senate District 33-:-State Senator Bart Hester-:-REP
GSU34DWED    State Senate District 34-:-Kaylee Wedgeworth-:-DEM
GSU34RDOT    State Senate District 34-:-Senator Jim Dotson-:-REP

## Processing Steps
Precinct and block shapefiles were retrieved from the sources listed above. The primary libraries used in processing are geopandas, pandas, and maup (https://github.com/mggg/maup) in Python.
The block data was prepared by creating the VAP_MOD field which is the total Voting Age Population (P0040001) minus Correctional Facility/Prison Population (P0050003) which will be used as the denominator in disaggregation.
The block file was queried out to include just the GEOID20, VAP_MOD, and geometry fields.
To assign blocks to precincts, the maup.assign function was used. Some blocks did not receive an assignment but nearly all of these had a VAP_MOD value of 0, meaning those blocks should not receive any votes during allocation anyway (these blocks have their PRECINCTID field set to "NO PRECINCT ASSIGNMENT"). In the rare instance where there was a block with a VAP_MOD > 0 and no precinct assignment, the nearest precinct within the same county was identified using minimum polygon boundary distance and used as the block's assignment.
After the blocks have received an assignment, they are grouped by their new assignment and summed to give a total VAP_MOD value for the precinct. A ratio is then calculated of VAP_MOD block / VAP_MOD precinct, which is applied to all candidate columns (see the Fields section above for the exact list of candidate columns in this dataset).
In some instances, there are precincts that sum to 0 for VAP_MOD but do contain votes. In order to not lose votes in the disaggregation process, these blocks are modified to VAP_MOD=1, then summed again to get a non-zero value denominator for VAP_MOD at the precinct. Therefore all blocks in the precinct would have the same ratio applied and receive the same distribution of votes. All blocks that have a modified VAP_MOD value were returned to their original value of 0 before extraction to maintain accuracy.
A key assumption of maup is that a block receives one precinct as an assignment. The RDH checks for any precincts with votes which have not been assigned to any blocks. In these instances, the block file is clipped to each precinct geometry, and the block which has the largest area inside the precinct receives all of the votes from that precinct.
The data are disaggregated from each of their respective split shapefiles (e.g. US House, State House, State Senate) from the source above, to preserve accuracy (rather than the _all_ file). They are joined back together and then a Hamilton rounding method is performed to ensure that all voters are whole numbers and sum exactly to the same totals.

## Additional Notes
Please direct questions related to processing this dataset to info@redistrictingdatahub.org